import qrcode

def main(args):
    if not args:
        print("Usage: qr <text>")
        return

    text = " ".join(args)

    qr = qrcode.QRCode(border=1)
    qr.add_data(text)
    qr.make(fit=True)

    matrix = qr.get_matrix()

    for row in matrix:
        print("".join("██" if cell else "  " for cell in row))