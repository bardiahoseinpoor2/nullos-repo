#!/usr/bin/env python3
"""
Single-file TCP Chat Application with Public Tunnel Support
Can run in either 'server' or 'client' mode.
"""

import json
import struct
import socket
import threading
import time
import sys
import os
import hashlib
import argparse
import subprocess
import shutil
import re

# ==========================================
# PROTOCOL LAYER
# ==========================================

def send_packet(sock: socket.socket, data: dict):
    """Serializes a dict to JSON and sends it with a 4-byte length prefix."""
    try:
        payload = json.dumps(data).encode('utf-8')
        header = struct.pack('!I', len(payload))
        sock.sendall(header + payload)
    except (ConnectionError, OSError) as e:
        raise ConnectionError(f"Failed to send data: {e}")

def recvall(sock: socket.socket, n: int) -> bytes:
    """Reads exactly n bytes from a socket."""
    data = bytearray()
    while len(data) < n:
        packet = sock.recv(n - len(data))
        if not packet:
            return None
        data.extend(packet)
    return bytes(data)

def receive_packet(sock: socket.socket) -> dict:
    """Reads a length prefix, then the payload, and deserializes the JSON."""
    try:
        header = recvall(sock, 4)
        if not header:
            return None
        
        length = struct.unpack('!I', header)[0]
        payload = recvall(sock, length)
        
        if not payload:
            return None
            
        return json.loads(payload.decode('utf-8'))
    except struct.error:
        return None
    except json.JSONDecodeError as e:
        print(f"[Protocol Error] Invalid JSON received: {e}")
        return None
    except (ConnectionError, OSError):
        return None

def get_timestamp() -> str:
    return time.strftime('%H:%M:%S')

# ==========================================
# TUNNEL LAYER
# ==========================================

class TunnelManager:
    def __init__(self):
        self.process = None
        self.public_address = None
        self._lock = threading.Lock()
        self.logs = []
        
    def start(self, port: int):
        """Detects available tools and starts the tunnel subprocess."""
        cmd = None
        
        if shutil.which('bore'):
            cmd = ["bore", "local", str(port), "--to", "bore.pub"]
            
        elif shutil.which('ssh'):
            ssh_dir = os.path.expanduser("~/.ssh")
            ed25519_key = os.path.join(ssh_dir, "id_ed25519")
            rsa_key = os.path.join(ssh_dir, "id_rsa")
            
            if not os.path.exists(ed25519_key) and not os.path.exists(rsa_key):
                print("[Public] No SSH key found. Generating one automatically...")
                os.makedirs(ssh_dir, exist_ok=True)
                subprocess.run(["ssh-keygen", "-t", "ed25519", "-q", "-N", "", "-f", ed25519_key])

            cmd = [
                "ssh", "-p", "443", f"-R0:localhost:{port}",
                "-o", "StrictHostKeyChecking=no", 
                "-o", "BatchMode=yes", 
                "-T", "tcp@a.pinggy.io"
            ]
            
        else:
            raise RuntimeError(
                "No free tunneling tools found.\n"
                "Please install bore (cargo install bore-cli) "
                "or ensure 'ssh' is installed."
            )

        self.process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            text=True,
            bufsize=1
        )
        
        thread = threading.Thread(target=self._read_output, daemon=True)
        thread.start()
        
        timeout = 15
        start_time = time.time()
        while time.time() - start_time < timeout:
            if self.get_public_address():
                return
            if self.process.poll() is not None:
                error_out = "".join(self.logs[-10:])
                raise RuntimeError(f"Tunnel exited unexpectedly. Code: {self.process.returncode}\nLogs:\n{error_out}")
            time.sleep(0.5)
            
        self.stop()
        error_out = "".join(self.logs[-10:])
        raise TimeoutError(f"Failed to retrieve public address within timeout.\nLogs:\n{error_out}")
        
    def _read_output(self):
        """Reads subprocess output to extract the public URL/IP."""
        if not self.process:
            return
            
        for line in iter(self.process.stdout.readline, ''):
            if not line:
                break
            
            self.logs.append(line)
                
            with self._lock:
                if "bore.pub" in line:
                    match = re.search(r"(bore\.pub:\d+)", line)
                    if match:
                        self.public_address = match.group(1)
                        
                elif "pinggy" in line:
                    # Matches lines like tcp://ylvft-49-13-30-50.run.pinggy-free.link:37443
                    match = re.search(r"tcp://([a-zA-Z0-9.-]+\.\w+:\d+)", line)
                    if match:
                        self.public_address = match.group(1)

    def get_public_address(self) -> str:
        with self._lock:
            return self.public_address
            
    def stop(self):
        if self.process and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.process.kill()

# ==========================================
# SERVER LAYER
# ==========================================

class ChatServer:
    def __init__(self, host: str, port: int, public: bool = False):
        self.host = host
        self.port = port
        self.public = public
        self.tunnel = None
        self.clients = {}  
        self.history = []
        self.max_history = 50
        self.clients_lock = threading.Lock()
        self.history_lock = threading.Lock()

    def broadcast(self, packet: dict, exclude_sock: socket.socket = None):
        with self.clients_lock:
            for sock in list(self.clients.keys()):
                if sock != exclude_sock:
                    try:
                        send_packet(sock, packet)
                    except ConnectionError:
                        self.remove_client(sock)

    def remove_client(self, sock: socket.socket):
        with self.clients_lock:
            if sock in self.clients:
                username = self.clients[sock]
                del self.clients[sock]
                try:
                    sock.close()
                except OSError:
                    pass
                
                print(f"[Server] {username} disconnected.")
                leave_packet = {
                    "type": "leave",
                    "user": "System",
                    "text": f"{username} has left the chat.",
                    "timestamp": get_timestamp()
                }
                threading.Thread(target=self.broadcast, args=(leave_packet,)).start()

    def handle_client(self, sock: socket.socket, addr):
        print(f"[Server] New connection established from {addr}")
        try:
            join_packet = receive_packet(sock)
            if not join_packet or join_packet.get("type") != "join":
                print(f"[Server] Invalid join packet from {addr}")
                return

            username = join_packet.get("user", "Anonymous")
            
            with self.clients_lock:
                if username in self.clients.values():
                    send_packet(sock, {"type": "system", "text": "Username already taken."})
                    return
                self.clients[sock] = username

            print(f"[Server] {addr} registered as {username}")

            with self.history_lock:
                for past_msg in self.history:
                    send_packet(sock, past_msg)

            join_notification = {
                "type": "join",
                "user": "System",
                "text": f"{username} has joined the chat.",
                "timestamp": get_timestamp()
            }
            self.broadcast(join_notification, exclude_sock=sock)

            while True:
                packet = receive_packet(sock)
                if packet is None:
                    break

                packet_type = packet.get("type")
                
                if packet_type == "message":
                    packet["timestamp"] = get_timestamp()
                    with self.history_lock:
                        self.history.append(packet)
                        if len(self.history) > self.max_history:
                            self.history.pop(0)
                    self.broadcast(packet)

                elif packet_type == "dm":
                    target_user = packet.get("target")
                    packet["timestamp"] = get_timestamp()
                    
                    with self.clients_lock:
                        target_sock = next((s for s, u in self.clients.items() if u == target_user), None)
                    
                    if target_sock:
                        try:
                            send_packet(target_sock, packet)
                            send_packet(sock, packet)
                        except ConnectionError:
                            self.remove_client(target_sock)
                    else:
                        send_packet(sock, {
                            "type": "system", 
                            "text": f"User '{target_user}' not found.",
                            "timestamp": get_timestamp()
                        })

                elif packet_type == "users":
                    with self.clients_lock:
                        user_list = ", ".join(self.clients.values())
                    send_packet(sock, {
                        "type": "system",
                        "text": f"Online users: {user_list}",
                        "timestamp": get_timestamp()
                    })

        except ConnectionError:
            pass
        except Exception as e:
            print(f"[Server Error] Unexpected error for {addr}: {e}")
        finally:
            self.remove_client(sock)

    def start(self):
        server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        try:
            server_sock.bind((self.host, self.port))
            server_sock.listen()
            print(f"[Server] Starting local chat server on port {self.port}...")
            
            if self.public:
                self.tunnel = TunnelManager()
                try:
                    print("[Public] Creating tunnel...")
                    self.tunnel.start(self.port)
                    addr = self.tunnel.get_public_address()
                    if addr:
                        parts = addr.split(":")
                        t_host = parts[0]
                        t_port = parts[1] if len(parts) > 1 else self.port
                        
                        print(f"[Public] Your server is available at:")
                        print(f"         {addr}")
                        print(f"\nUsers can connect with:")
                        print(f"python3 chat.py client {t_host} -p {t_port} -u username\n")
                    else:
                        print("[Public] Failed to parse public address from tunnel.")
                except Exception as e:
                    print(f"[Public] Error starting tunnel: {e}")
                    return

            while True:
                sock, addr = server_sock.accept()
                client_thread = threading.Thread(target=self.handle_client, args=(sock, addr), daemon=True)
                client_thread.start()
                
        except KeyboardInterrupt:
            print("\n[Server] Shutting down.")
        except Exception as e:
            print(f"[Server] Failed to start: {e}")
        finally:
            if self.tunnel:
                self.tunnel.stop()
            server_sock.close()

# ==========================================
# CLIENT LAYER
# ==========================================

class ChatClient:
    def __init__(self, host: str, port: int, username: str):
        self.host = host
        self.port = port
        self.username = username
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
        self.RESET = "\033[0m"
        self.BOLD = "\033[1m"
        self.SYS_COLOR = "\033[93m"
        self.DM_COLOR = "\033[95m"
        self.TIME_COLOR = "\033[90m"

    def get_user_color(self, username: str) -> str:
        colors = ["\033[91m", "\033[92m", "\033[94m", "\033[96m", "\033[33m", "\033[35m"]
        hash_val = int(hashlib.md5(username.encode()).hexdigest(), 16)
        return colors[hash_val % len(colors)]

    def receive_messages(self):
        while True:
            try:
                packet = receive_packet(self.sock)
                if packet is None:
                    print(f"\n{self.SYS_COLOR}[System] Disconnected from server.{self.RESET}")
                    self.sock.close()
                    os._exit(0)
                
                p_type = packet.get("type")
                user = packet.get("user", "Unknown")
                text = packet.get("text", "")
                timestamp = packet.get("timestamp", "00:00:00")
                
                time_str = f"{self.TIME_COLOR}[{timestamp}]{self.RESET}"
                sys.stdout.write("\033[2K\r") 
                
                if p_type == "message":
                    u_color = self.get_user_color(user)
                    print(f"{time_str} {self.BOLD}{u_color}{user}{self.RESET}: {text}")
                elif p_type in ("join", "leave", "system"):
                    print(f"{time_str} {self.SYS_COLOR}{text}{self.RESET}")
                elif p_type == "dm":
                    u_color = self.get_user_color(user)
                    target = packet.get("target")
                    print(f"{time_str} {self.DM_COLOR}(DM to {target}){self.RESET} {self.BOLD}{u_color}{user}{self.RESET}: {text}")
                    
                sys.stdout.write("> ")
                sys.stdout.flush()

            except OSError:
                break

    def start(self):
        try:
            self.sock.connect((self.host, self.port))
        except Exception as e:
            print(f"Failed to connect to {self.host}:{self.port}: {e}")
            sys.exit(1)

        try:
            send_packet(self.sock, {"type": "join", "user": self.username})
        except ConnectionError:
            print("Failed to send join packet.")
            sys.exit(1)

        recv_thread = threading.Thread(target=self.receive_messages, daemon=True)
        recv_thread.start()

        print(f"{self.SYS_COLOR}Connected! Type /quit to exit, /users to see online users, or /dm <user> <msg>.{self.RESET}")
        
        try:
            while True:
                msg = input("> ").strip()
                if not msg:
                    continue
                
                try:
                    if msg.startswith("/"):
                        parts = msg.split(maxsplit=2)
                        command = parts[0].lower()
                        
                        if command == "/quit":
                            break
                        elif command == "/users":
                            send_packet(self.sock, {"type": "users"})
                        elif command == "/dm":
                            if len(parts) < 3:
                                print(f"{self.SYS_COLOR}Usage: /dm <username> <message>{self.RESET}")
                            else:
                                send_packet(self.sock, {
                                    "type": "dm",
                                    "user": self.username,
                                    "target": parts[1],
                                    "text": parts[2]
                                })
                        else:
                            print(f"{self.SYS_COLOR}Unknown command: {command}{self.RESET}")
                    else:
                        send_packet(self.sock, {
                            "type": "message",
                            "user": self.username,
                            "text": msg
                        })
                except ConnectionError:
                    print(f"\n{self.SYS_COLOR}Connection lost. Unable to send message.{self.RESET}")
                    break
        except (KeyboardInterrupt, EOFError):
            pass
        finally:
            self.sock.close()

# ==========================================
# CLI ENTRY POINT
# ==========================================

def main():
    parser = argparse.ArgumentParser(description="Single-file TCP Chat Application")
    subparsers = parser.add_subparsers(dest="mode", required=True, help="Mode to run the application in")

    # Server arguments
    server_parser = subparsers.add_parser("server", help="Run as chat server")
    server_parser.add_argument("--host", type=str, default="0.0.0.0", help="Host IP to bind to (default: 0.0.0.0)")
    server_parser.add_argument("-p", "--port", type=int, default=5000, help="Port to listen on (default: 5000)")
    server_parser.add_argument("--public", action="store_true", help="Automatically expose server to the internet")

    # Client arguments
    client_parser = subparsers.add_parser("client", help="Run as chat client")
    client_parser.add_argument("host", type=str, help="Server IP or domain to connect to")
    client_parser.add_argument("-p", "--port", type=int, default=5000, help="Server port (default: 5000)")
    client_parser.add_argument("-u", "--username", type=str, required=True, help="Your username")

    args = parser.parse_args()

    if args.mode == "server":
        server = ChatServer(args.host, args.port, args.public)
        server.start()
    elif args.mode == "client":
        client = ChatClient(args.host, args.port, args.username)
        client.start()

if __name__ == "__main__":
    main()
