# tunnel.py
import subprocess
import threading
import shutil
import re
import time

class TunnelManager:
    def __init__(self):
        self.process = None
        self.public_address = None
        self._lock = threading.Lock()
        
    def start(self, port: int):
        """Detects available tools and starts the tunnel subprocess."""
        cmd = None
        
        # 1. Try bore (Preferred for TCP)
        if shutil.which('bore'):
            cmd = ["bore", "local", str(port), "--to", "bore.pub"]
            
        # 2. Try localhost.run via SSH
        elif shutil.which('ssh'):
            cmd = [
                "ssh", "-o", "StrictHostKeyChecking=no", 
                "-R", f"0:localhost:{port}", "nokey@localhost.run", "-T", "-n"
            ]
            
        # 3. Try cloudflared
        elif shutil.which('cloudflared'):
            cmd = ["cloudflared", "tunnel", "--url", f"tcp://localhost:{port}"]
            
        else:
            raise RuntimeError(
                "No free tunneling tools found.\n"
                "Please install bore:\n"
                "  cargo install bore-cli\n"
                "Or ensure 'ssh' is installed for localhost.run."
            )

        # Start process with merged stdout/stderr to capture all logs
        self.process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1
        )
        
        # Start background thread to parse the output stream
        thread = threading.Thread(target=self._read_output, daemon=True)
        thread.start()
        
        # Wait up to 15 seconds for the public address to be parsed
        timeout = 15
        start_time = time.time()
        while time.time() - start_time < timeout:
            if self.get_public_address():
                return
            if self.process.poll() is not None:
                raise RuntimeError(f"Tunnel process exited unexpectedly. Return code: {self.process.returncode}")
            time.sleep(0.5)
            
        self.stop()
        raise TimeoutError("Failed to retrieve public address within timeout.")
        
    def _read_output(self):
        """Reads subprocess output line-by-line to extract the public URL/IP."""
        if not self.process:
            return
            
        for line in iter(self.process.stdout.readline, ''):
            if not line:
                break
                
            with self._lock:
                # Parse bore output
                if "bore.pub" in line:
                    match = re.search(r"(bore\.pub:\d+)", line)
                    if match:
                        self.public_address = match.group(1)
                        
                # Parse localhost.run output
                elif "localhost.run" in line:
                    # SSH output usually looks like: "tunneled with tls termination, https://..."
                    # Or for raw TCP ports: "port 12345 forwarded to localhost"
                    match = re.search(r"([a-zA-Z0-9.-]+\.localhost\.run):?(\d+)?", line)
                    if match:
                        domain = match.group(1)
                        port = match.group(2) if match.group(2) else "80"
                        self.public_address = f"{domain}:{port}"
                        
                # Parse cloudflared output
                elif "trycloudflare.com" in line:
                    match = re.search(r"(https?://[a-zA-Z0-9.-]+\.trycloudflare\.com)", line)
                    if match:
                        self.public_address = match.group(1)
            
            # If address is found, we can stop parsing actively, but we keep reading to prevent pipe block
            if self.public_address:
                pass 

    def get_public_address(self) -> str:
        with self._lock:
            return self.public_address
            
    def stop(self):
        """Terminates the tunnel subprocess gracefully."""
        if self.process and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.process.kill()