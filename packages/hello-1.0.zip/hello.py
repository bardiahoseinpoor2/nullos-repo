def run():
    print("Hello from NullOS!")

if __name__ == "__main__":
    run()