import os
import json

LOGO = r"""
      _   _       _ _    ___  ____
     | \ | |     | | |  / _ \|  _ \
     |  \| | ___ | | | | | | | |_) |
     | |\  |/ _ \| | | | |_| |  __/
     |_| \_/\___/|_|_|  \___/|_|
"""

print(LOGO)

try:
    with open("settings.json") as f:
        settings = json.load(f)
except:
    settings = {}

try:
    with open("commands.json") as f:
        commands = json.load(f)
    packages = len(commands)
except:
    packages = 0

print("NullOS")
print("----------------")
print(f"Kernel: NullKernel")
print(f"Shell: NullShell")
print(f"Packages: {packages}")
print(f"User: {settings.get('user', 'null')}")
print(f"Directory: {os.getcwd()}")
print("----------------")