# calc.py

import math

def main(args=None):
    print("NullOS Calculator")
    print("Type 'exit' to quit")

    while True:
        expr = input("calc> ").strip()

        if expr.lower() in ["exit", "quit"]:
            break

        try:
            result = eval(
                expr,
                {
                    "__builtins__": {},
                    "math": math,
                    "sqrt": math.sqrt,
                    "sin": math.sin,
                    "cos": math.cos,
                    "tan": math.tan,
                    "pi": math.pi,
                    "e": math.e,
                    "pow": pow,
                    "abs": abs,
                    "round": round,
                },
                {},
            )

            print(result)

        except Exception as e:
            print(f"Error: {e}")


if __name__ == "__main__":
    main()