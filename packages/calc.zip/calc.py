def main(args):
    if not args:
        print("Usage: calc <expression>")
        return

    expr = " ".join(args)

    try:
        result = eval(
            expr,
            {"__builtins__": {}},
            {}
        )
        print(result)

    except Exception as e:
        print(f"Error: {e}")
