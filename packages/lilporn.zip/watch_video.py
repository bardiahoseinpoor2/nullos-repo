import time
import os


FPS = 36 


# List of available video files
OPTIONS = [
    "video.txt",
    "video2.txt",
    "video3.txt",
    "video4.txt",
]

# Display menu options
print("Select a file to play:")
for idx, filename in enumerate(OPTIONS, 1):
    print(f"{idx}. {filename}")

# Get and validate user input
choice = None
while choice not in range(1, len(OPTIONS) + 1):
    try:
        choice = int(input("\nEnter choice (1-4): "))
    except ValueError:
        pass

selected_file = OPTIONS[choice - 1]

# Load and play the selected file
if not os.path.exists(selected_file):
    print(f"Error: {selected_file} not found.")
    exit(1)

with open(selected_file, "r", encoding="utf-8") as f:
    content = f.read()

frames = content.split("=== FRAME ")

for frame in frames[1:]:
    os.system("clear")
    print(frame.split("\n", 1)[1], end="")
    time.sleep(1 / FPS)