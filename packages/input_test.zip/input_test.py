x = input("type smt: ")
print(x)