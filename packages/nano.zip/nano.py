import curses


class NanoEditor:

    def __init__(self, fs, filename):
        self.fs = fs
        self.filename = filename

        try:
            content = fs.read_file(filename)
            self.lines = content.split("\n")
        except FileNotFoundError:
            self.lines = [""]

        self.x = 0
        self.y = 0
        self.scroll = 0


    def save(self):
        content = "\n".join(self.lines)
        self.fs.write_file(self.filename, content)


    def run(self, screen):

        curses.curs_set(1)
        screen.keypad(True)

        while True:

            height, width = screen.getmaxyx()

            screen.clear()


            # draw text
            for i, line in enumerate(self.lines):

                row = i - self.scroll

                if 0 <= row < height - 2:
                    screen.addstr(
                        row,
                        0,
                        line[:width-1]
                    )


            # status
            status = (
                f"CTRL+S Save | CTRL+Q Quit | "
                f"{self.filename}"
            )

            screen.addstr(
                height-1,
                0,
                status[:width-1]
            )


            screen.move(
                self.y-self.scroll,
                self.x
            )

            screen.refresh()


            key = screen.getch()


            # CTRL+Q
            if key == 17:
                break


            # CTRL+S
            elif key == 19:
                self.save()


            elif key == curses.KEY_UP:
                if self.y > 0:
                    self.y -= 1


            elif key == curses.KEY_DOWN:
                if self.y < len(self.lines)-1:
                    self.y += 1


            elif key == curses.KEY_LEFT:
                if self.x > 0:
                    self.x -= 1


            elif key == curses.KEY_RIGHT:
                if self.x < len(self.lines[self.y]):
                    self.x += 1


            elif key == 10:
                line = self.lines[self.y]

                self.lines[self.y] = line[:self.x]

                self.lines.insert(
                    self.y+1,
                    line[self.x:]
                )

                self.y += 1
                self.x = 0


            elif key in (8,127):
                if self.x > 0:

                    line = self.lines[self.y]

                    self.lines[self.y] = (
                        line[:self.x-1]
                        +
                        line[self.x:]
                    )

                    self.x -= 1


            elif 32 <= key <= 126:

                line = self.lines[self.y]

                self.lines[self.y] = (
                    line[:self.x]
                    +
                    chr(key)
                    +
                    line[self.x:]
                )

                self.x += 1



def launch(fs, filename):
    editor = NanoEditor(fs, filename)
    curses.wrapper(editor.run)