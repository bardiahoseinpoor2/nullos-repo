import sys
import subprocess
import tempfile
import os


def run_code(code):
    try:
        subprocess.run(
            ["python", "-c", code],
            check=True
        )

    except subprocess.CalledProcessError as e:
        print(f"Python exited with code {e.returncode}")


def run_file(file):
    try:
        subprocess.run(
            ["python", file],
            check=True
        )

    except FileNotFoundError:
        print("File not found:", file)

    except subprocess.CalledProcessError as e:
        print(f"Python exited with code {e.returncode}")


def main():

    args = sys.argv[1:]

    if not args:
        print("Usage:")
        print("python <file.py>")
        print("python -C <code>")
        return


    if args[0] == "-C":

        if len(args) < 2:
            print("Missing code")
            return

        code = " ".join(args[1:])
        run_code(code)

    else:
        run_file(args[0])


if __name__ == "__main__":
    main()