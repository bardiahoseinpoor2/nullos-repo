import secrets
import string

SYMBOLS = "!@#$%^&*-_=+?"

USAGE = """passgen - generate secure random passwords

Usage:
  passgen [length] [options]

Options:
  -c, --count N      Number of passwords to generate (default: 1)
  -s, --no-symbols   Use letters and digits only (no symbols)
  -h, --help         Show this help

Examples:
  passgen              # one 16-character password
  passgen 24           # one 24-character password
  passgen -c 5         # five passwords
  passgen 20 -s        # 20 chars, letters and digits only"""


def _positive_int(value, label):
    try:
        n = int(value)
    except ValueError:
        raise ValueError(f"{label} must be a whole number.")
    if n <= 0:
        raise ValueError(f"{label} must be positive.")
    return n


def _parse_args(args):
    length = 16
    count = 1
    symbols = True

    i = 0
    while i < len(args):
        arg = args[i]
        if arg in ("-h", "--help"):
            return None
        if arg in ("-s", "--no-symbols"):
            symbols = False
        elif arg in ("-c", "--count"):
            i += 1
            if i >= len(args):
                raise ValueError("--count needs a number.")
            count = _positive_int(args[i], "--count")
        elif arg.startswith("--count="):
            count = _positive_int(arg.split("=", 1)[1], "--count")
        elif arg in ("-l", "--len"):
            i += 1
            if i >= len(args):
                raise ValueError("--len needs a number.")
            length = _positive_int(args[i], "length")
        elif arg.startswith("--len="):
            length = _positive_int(arg.split("=", 1)[1], "length")
        else:
            length = _positive_int(arg, "length")
        i += 1

    # Keep lengths and counts sane.
    length = max(4, min(length, 128))
    count = max(1, min(count, 100))
    return length, count, symbols


def _generate(length, symbols):
    pool = string.ascii_letters + string.digits
    if symbols:
        pool += SYMBOLS
    # secrets.choice uses a cryptographic RNG, unlike random.choice.
    return "".join(secrets.choice(pool) for _ in range(length))


def run(args, arg_str="", stdin=""):
    try:
        parsed = _parse_args(args)
    except ValueError as exc:
        return f"Error: {exc}\n\n{USAGE}"
    if parsed is None:
        return USAGE
    length, count, symbols = parsed
    passwords = [_generate(length, symbols) for _ in range(count)]
    return "\n".join(passwords)
