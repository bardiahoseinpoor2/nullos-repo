from PIL import Image
import requests
from io import BytesIO

ASCII = "@%#*+=-:. "

def image_to_ascii(img, width=80):
    img = img.convert("L")

    aspect = img.height / img.width
    height = int(width * aspect * 0.5)

    img = img.resize((width, height))

    pixels = img.getdata()

    chars = "".join(
        ASCII[p * (len(ASCII) - 1) // 255]
        for p in pixels
    )

    lines = [
        chars[i:i + width]
        for i in range(0, len(chars), width)
    ]

    return "\n".join(lines)

def main(args):
    if not args:
        print("Usage: asciiimg <image_url>")
        return

    r = requests.get(args[0], timeout=10)
    img = Image.open(BytesIO(r.content))

    print(image_to_ascii(img))