from bs4 import BeautifulSoup
import requests

def main(args):
    if not args:
        print("Usage: browse <url>")
        return

    url = args[0]

    try:
        html = requests.get(url, timeout=10).text
        soup = BeautifulSoup(html, "html.parser")

        if soup.title:
            print("=" * 80)
            print(soup.title.get_text(strip=True).center(80))
            print("=" * 80)
            print()

        for tag in soup.find_all(["h1", "h2", "h3", "p", "a"]):
            if tag.name == "h1":
                print("\n#" * 40)
                print(tag.get_text(strip=True).upper())
                print("#" * 40)

            elif tag.name == "h2":
                print(f"\n== {tag.get_text(strip=True)} ==")

            elif tag.name == "h3":
                print(f"\n-- {tag.get_text(strip=True)} --")

            elif tag.name == "p":
                text = tag.get_text(" ", strip=True)
                if text:
                    print(text)
                    print()

            elif tag.name == "a":
                text = tag.get_text(strip=True)
                href = tag.get("href", "")
                if text:
                    print(f"[{text}] -> {href}")

    except Exception as e:
        print(f"Error: {e}")
