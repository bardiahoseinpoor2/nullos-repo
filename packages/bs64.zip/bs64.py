import base64

def run(args):
    if len(args) < 2:
        return (
            "Usage:\n"
            "  base64 encode <text>\n"
            "  base64 decode <text>"
        )

    action = args[0].lower()
    text = " ".join(args[1:])

    try:
        if action == "encode":
            encoded = base64.b64encode(text.encode()).decode()
            return encoded

        elif action == "decode":
            decoded = base64.b64decode(text.encode()).decode()
            return decoded

        else:
            return "Unknown action. Use 'encode' or 'decode'."

    except Exception as e:
        return f"Error: {e}"
