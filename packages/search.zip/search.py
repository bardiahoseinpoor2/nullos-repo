import nframe # type: ignore

print(nframe.run("ls"))