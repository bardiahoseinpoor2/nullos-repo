import nframe # type: ignore

ls_output = nframe.run("ls")

#take arguements to search
search_term = input("Enter search term: ")

for line in ls_output.split("\n"):
    if search_term in line:
        print(line)
        